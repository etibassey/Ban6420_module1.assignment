
# lists of the first names and last names
female_first_names <- c("Blessing", "Mary", "Eno", "Jenny", "Linda", "Ngozi", "Chikama", "Susan", "Ayokumi", "Sarah", "Tosin")
male_first_names <- c("John", "Joshua", "Robert", "Obi", "Johnny", "Ade", "Peter", "Mustapha", "Charles", "Chris")
last_names <- c("Asido", "Uduka", "Akpan", "Udo", "Obinna", "Ezeani", "Adeleke", "Adamu", "Ifeanyi", "Edet") 

# function to generate random salary
generate_salary <- function() {
  return(round(runif(1, min = 4000, max = 30000), 2))
}

  
# function to randomly assign gender
generate_gender <- function() {
  return(sample(c("Male", "Female"), 1))
}

# function generate full names
generate_full_name <- function(gender) {
  if (gender == "Female") {
    first_name <- sample(female_first_names, 1)
  } else {
    first_name <- sample(male_first_names, 1)
  }
  last_name <- sample(last_names, 1)
  return(paste(first_name, last_name))
}

# generate list of workers with full real names
workers <- data.frame(id = integer(),
                      name = character(),
                      salary = numeric(),
                      gender = character(),
                      stringsAsFactors = FALSE)


for (num in 1:400) {
  gender <- generate_gender()
  worker <- data.frame(
    id = num,
    name = generate_full_name(gender),
    salary = generate_salary(),
    gender = gender,
    stringsAsFactors = FALSE
  )
  workers <- rbind(workers, worker)
} 


# generate payment slip with conditional statements
workers$employment_level <- sapply(1:nrow(workers), function(i) {
  salary <- workers$salary[i]
  gender <- workers$gender[i]
  
  if (10000 < salary && salary < 20000) {
    return('A1')
  } else if (7500 < salary && salary < 30000 && gender == 'Female') {
    return('A5-F')
  } else {
    return('None')
  }
})

# print all employee details
for (i in 1:nrow(workers)) {
  cat(sprintf("Employee ID: %d,\n", workers$id[i]))
  cat(sprintf("Name: %s,\n", workers$name[i]))
  cat(sprintf("Salary: %.2f,\n", workers$salary[i]))
  cat(sprintf("Gender: %s,\n", workers$gender[i]))
  cat(sprintf("Level: %s\n\n", workers$employment_level[i]))
}