#!/usr/bin/env python
# coding: utf-8

# In[4]:


import random

# list of First names and last names
female_first_names = ["Blessing", "Mary", "Eno", "Jenny", "Linda", "Ngozi", "Chikama", "Susan", "Ayokumi", "Sarah", "Tosin"]
male_first_names = ["John", "Joshua", "Robert", "Obi", "Johnny", "Ade", "Peter", "Mustapha", "Charles", "Chris"]
last_names = ["Asido", "Uduka", "Akpan", "Udo", "Obinna", "Ezeani", "Adeleke", "Adamu", "Ifeanyi", "Edet"]

# function to generate random salary
def generate_salary():
    return round(random.uniform(4000, 30000), 2) 

# function to randomly assign gender
def generate_gender():
    return random.choice(['Male', 'Female'])

# function generating full name
def generate_full_name(gender):
    if gender =='Female':
        first_name = random.choice(female_first_names)
    else: 
        first_name = random.choice(male_first_names)
    last_name = random.choice(last_names)
    return f"{first_name} {last_name}"

# Generate list of workers with full real names
workers = []
for num in range(1, 401): 
    gender = generate_gender()
    worker = {
            'id': num,
            'name': generate_full_name(gender),
            'salary': generate_salary(),
            'gender': gender
    }
    workers.append(worker)

# Generate payment slip with conditional statements
for worker in workers:
    try:
        salary = worker["salary"]
        gender = worker["gender"]
        
        if 10000 < salary < 20000:
            worker["employment_level"] = 'A1'
        elif 7500 < salary < 30000 and gender == 'Female':
            worker['employment_level'] = 'A5-F'
        else:
            worker['employment_level'] = 'None'
            
    except Exception as e:
        print(f"Error generating payment slip for {worker['name']}: {e}")
           
# Print all employee details
for worker in workers:
        print(f"Employee ID: {worker['id']},\n"
          f"Name: {worker['name']},\n"
          f"Salary: {worker['salary']},\n"
          f"Gender: {worker['gender']},\n"
          f"Level: {worker['employment_level']}\n")
    

    




    
    



# 

# In[ ]:




