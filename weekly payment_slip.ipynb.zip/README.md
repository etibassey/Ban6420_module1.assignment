 ## Overview
This project contains python and R scripts to facilitate the weekly payments of workers for Highridge Construction Company. The scripts generate payment slips for 400 workers, assigning employee levels, employment ID based on salary and gender of each worker.

## Files
weekly payment_slip.ipynb: The Python script to generate payment slips.
weekly payment_slip.R: The R script to generate payment slips
README.md: This file.

Requirements
Anaconda Navigator
2.6.2 package by Anaconda, Inc

## Instroduction

### Python
1. Ensure you have Python installed.
2. Install the required Python package:
3. Run the script:

### R
1. Ensure you have R installed.
2. Install the required R package:
3. Run the script:


## Functionality
 Generates a list of 400 workers with random salaries, gender, employee id, and level. 
 Assigns employee levels based on salary and gender conditions.
 Prints payment slips for each worker, including salary, gender, and level.

## Author
Etimbuk E. Bassey, Software Engineer at Highridge Construction Company.

